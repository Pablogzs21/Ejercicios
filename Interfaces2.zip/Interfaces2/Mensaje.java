package Interfaces2;
import java.util.Objects;
public class Mensaje {
    private String mensaje;
    private String prioridad;

    public Mensaje(String mensaje) {
        this.mensaje = mensaje;
        this.prioridad = "normal";
    }

    public String leerMensaje() {
        return this.mensaje;
    }

    public void cambiarMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public void cambiarPrioridadAlta() {
        this.prioridad = "alta";
    }

    public void cambiarPrioridadMedia() {
        this.prioridad = "media";
    }

    public void cambiarPrioridadBaja() {
        this.prioridad = "baja";
    }

    @Override
    public String toString() {
        return "Mensaje{" +
                "mensaje='" + mensaje + '\'' +
                ", prioridad='" + prioridad + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Mensaje mensaje1 = (Mensaje) o;
        return Objects.equals(mensaje, mensaje1.mensaje) &&
                Objects.equals(prioridad, mensaje1.prioridad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mensaje, prioridad);
    }
}

