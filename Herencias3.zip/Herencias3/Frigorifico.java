package Herencias3;

public class Frigorifico extends Electrodomestico {
    private int temperatura;

    public Frigorifico(String marca, String modelo, int consumo, int temperatura) {
        super(marca, modelo, consumo);
        this.temperatura = temperatura;
    }

    public Frigorifico(Frigorifico otro) {
        super(otro);
        this.temperatura = otro.temperatura;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    @Override
    public String toString() {
        return super.toString() + ", temperatura: " + temperatura;
    }

    @Override
    public Frigorifico clone() {
        return new Frigorifico(this);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Frigorifico other = (Frigorifico) obj;
        if (temperatura != other.temperatura)
            return false;
        return true;
    }
}

