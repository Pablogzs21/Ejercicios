package Herencias3;
import java.util.Objects;
public class Electrodomestico {
    private String marca;
    private String modelo;
    private int consumoWatios;

    public Electrodomestico(String marca, String modelo, int consumoWatios) {
        this.marca = marca;
        this.modelo = modelo;
        this.consumoWatios = consumoWatios;
    }

    public Electrodomestico(Electrodomestico electrodomestico) {
        this.marca = electrodomestico.marca;
        this.modelo = electrodomestico.modelo;
        this.consumoWatios = electrodomestico.consumoWatios;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getConsumoWatios() {
        return consumoWatios;
    }

    public void setConsumoWatios(int consumoWatios) {
        this.consumoWatios = consumoWatios;
    }

    @Override
    public String toString() {
        return "Electrodomestico{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", consumoWatios=" + consumoWatios +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Electrodomestico that = (Electrodomestico) o;
        return consumoWatios == that.consumoWatios &&
                Objects.equals(marca, that.marca) &&
                Objects.equals(modelo, that.modelo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(marca, modelo, consumoWatios);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

