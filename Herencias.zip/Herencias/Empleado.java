package Herencias;

public class Empleado extends Persona {
    private int idEmpleado;
    private final String departamento;
    private final Persona jefe;

    public Empleado(String nombre, String apellidos, String dni, int anyoNacimiento, int idEmpleado, String departamento, Persona jefe) {
        super(nombre, apellidos, dni, anyoNacimiento);
        this.idEmpleado = idEmpleado;
        this.departamento = departamento;
        this.jefe = jefe;
    }

    public Empleado(Empleado empleado) {
        super(empleado.getNombre(), empleado.getApellidos(), empleado.getDni(), empleado.getAnyoNacimiento());
        this.idEmpleado = empleado.idEmpleado;
        this.departamento = empleado.departamento;
        this.jefe = empleado.jefe;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getDepartamento() {
        return departamento;
    }

    public Persona getJefe() {
        return jefe;
    }

    @Override
    public String toString() {
        return super.toString() + "\nID Empleado: " + idEmpleado + "\nDepartamento: " + departamento + "\nJefe: " + jefe;
    }

    @Override
    public Empleado clone() {
        return new Empleado(this);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Empleado)) {
            return false;
        }
        Empleado empleado = (Empleado) obj;
        return super.equals(empleado) && idEmpleado == empleado.idEmpleado && departamento.equals(empleado.departamento)
                && jefe.equals(empleado.jefe);
    }
}
