package actividades.pablo;

import static org.junit.Assert.*;

import org.junit.Test;



import java.util.Random;

public class PruebaEdadPersonasTest {

    @Test
    public void testGeneraExcepcionEdad() throws Exception {
        PruebaEdadPersonas pep = new PruebaEdadPersonas();
        Random rand = new Random();
        
        for (int i = 0; i < 100; i++) {
            int edad = rand.nextInt(100) + 1;
            try {
                pep.generaExcepcionEdad(edad);
            } catch (InfantilException e) {
                System.out.println("Excepcion infantil generada para edad: " + edad);
            } catch (AdultoException e) {
                System.out.println("Excepcion adulto generada para edad: " + edad);
            } catch (MayorException e) {
                System.out.println("Excepcion mayor generada para edad: " + edad);
            }
        }
    }

    @Test
    public void testGeneraExcepcionEdadException() {
        PruebaEdadPersonas pep = new PruebaEdadPersonas();
        Random rand = new Random();
        
        for (int i = 0; i < 100; i++) {
            int edad = rand.nextInt(100) + 1;
            try {
                pep.generaExcepcionEdad(edad);
            } catch (Exception e) {
                System.out.println("Excepcion capturada para edad: " + edad);
                System.out.println("Mensaje de la excepcion: " + e.getMessage());
            }
        }
    }
}
