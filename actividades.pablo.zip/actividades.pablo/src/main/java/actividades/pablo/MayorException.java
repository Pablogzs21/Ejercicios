package actividades.pablo;

public class MayorException extends Exception {
    public MayorException(String message) {
        super(message);
    }
}

