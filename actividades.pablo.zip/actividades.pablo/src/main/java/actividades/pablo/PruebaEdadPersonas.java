package actividades.pablo;

import java.util.Random;

public class PruebaEdadPersonas {
    public void generaExcepcionEdad(int edad) throws Exception {
        if (edad < 18) {
            throw new InfantilException("La edad es menor de 18 años.");
        } else if (edad >= 18 && edad < 65) {
            throw new AdultoException("La edad está entre 18 y 65 años.");
        } else if (edad >= 65) {
            throw new MayorException("La edad es mayor de 65 años.");
        }
    }
    
    public static void main(String[] args) throws Exception {
        PruebaEdadPersonas prueba = new PruebaEdadPersonas();
        Random random = new Random();
        
        // Primer test
        for (int i = 0; i < 100; i++) {
            int edad = random.nextInt(100) + 1;
            try {
                prueba.generaExcepcionEdad(edad);
            } catch (InfantilException e) {
                System.out.println("Se ha generado una excepción InfantilException: " + e.getMessage());
            } catch (AdultoException e) {
                System.out.println("Se ha generado una excepción AdultoException: " + e.getMessage());
            } catch (MayorException e) {
                System.out.println("Se ha generado una excepción MayorException: " + e.getMessage());
            }
        }
        
        // Segundo test
        for (int i = 0; i < 100; i++) {
            int edad = random.nextInt(100) + 1;
            try {
                prueba.generaExcepcionEdad(edad);
            } catch (Exception e) {
                System.out.println("Se ha generado una excepción: " + e.getMessage());
            }
        }
    }
}

