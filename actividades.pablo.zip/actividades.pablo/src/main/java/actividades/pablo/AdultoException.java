package actividades.pablo;

public class AdultoException extends Exception {
    public AdultoException(String message) {
        super(message);
    }
}

