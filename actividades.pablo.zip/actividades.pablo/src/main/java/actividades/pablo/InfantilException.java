package actividades.pablo;

public class InfantilException extends Exception {
    public InfantilException(String message) {
        super(message);
    }
}

