package ObjetosComplejos;

import java.util.Date;

public class ProfesorInterino extends Profesor {
    private Date fechaInterinidad;

    public ProfesorInterino(String nombre, String apellidos, int edad, String idProfesor, String asignatura, Date fechaInterinidad) {
        super(nombre, apellidos, edad, idProfesor, asignatura);
        this.fechaInterinidad = fechaInterinidad;
    }

    public ProfesorInterino(ProfesorInterino other) {
        super(other);
        this.fechaInterinidad = other.fechaInterinidad;
    }

    public Date getFechaInterinidad() {
        return fechaInterinidad;
    }

    public void setFechaInterinidad(Date fechaInterinidad) {
        this.fechaInterinidad = fechaInterinidad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProfesorInterino)) return false;
        if (!super.equals(o)) return false;
        ProfesorInterino that = (ProfesorInterino) o;
        return fechaInterinidad.equals(that.fechaInterinidad);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + fechaInterinidad.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "ProfesorInterino{" +
                "nombre='" + getNombre() + '\'' +
                ", apellidos='" + getApellidos() + '\'' +
                ", edad=" + getEdad() +
                ", idProfesor='" + getIdProfesor() + '\'' +
                ", asignatura='" + getAsignatura() + '\'' +
                ", fechaInterinidad=" + fechaInterinidad +
                '}';
    }

    @Override
    public ProfesorInterino clone() {
        return new ProfesorInterino(this);
    }
}

