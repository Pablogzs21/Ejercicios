package ObjetosComplejos;
import java.util.Objects;
public class Profesor extends Persona {
    private String idProfesor;
    private String asignatura;

    public Profesor(String nombre, String apellidos, int edad, String idProfesor, String asignatura) {
        super(nombre, apellidos, edad);
        this.idProfesor = idProfesor;
        this.asignatura = asignatura;
    }

    public Profesor(Profesor profesor) {
        super(profesor);
        this.idProfesor = profesor.idProfesor;
        this.asignatura = profesor.asignatura;
    }

    public String getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(String idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Profesor)) return false;
        if (!super.equals(obj)) return false;
        Profesor profesor = (Profesor) obj;
        return Objects.equals(idProfesor, profesor.idProfesor) &&
               Objects.equals(asignatura, profesor.asignatura);
    }

    @Override
    public String toString() {
        return super.toString() + " - Id profesor: " + idProfesor + " - Asignatura: " + asignatura;
    }

    @Override
    public Profesor clone() {
        return new Profesor(this);
    }
}

