package ejercicios.pablo;

import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.Test;

public class CaracterTecladoTest {
    @Test
    public void testLeerCaracteres() {
        CaracterTeclado ct = new CaracterTeclado();
        boolean salir = false;
        while (!salir) {
            try {
                ct.procesarCaracter();
            } catch (ExcepcionVocal e) {
                System.out.println(e.getMessage());
            } catch (ExcepcionNumero e) {
                System.out.println(e.getMessage());
            } catch (ExcepcionBlanco e) {
                System.out.println(e.getMessage());
            } catch (ExcepcionSalida e) {
                System.out.println(e.getMessage());
                salir = true;
            }
        }
    }
}

