package ejercicios.pablo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LeerPorTeclado {
    private char caracter;

    public char getChar() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            this.caracter = (char) br.read();
        } catch (IOException e) {
            System.out.println("Error de lectura.");
        }
        return this.caracter;
    }
}
