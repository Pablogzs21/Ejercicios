package ejercicios.pablo;

public class ExcepcionNumero extends Exception {
    public ExcepcionNumero() {
        super("Error: el carácter leído es un número.");
    }
}
