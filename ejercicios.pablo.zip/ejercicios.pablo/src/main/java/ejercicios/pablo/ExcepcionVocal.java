package ejercicios.pablo;

public class ExcepcionVocal extends Exception {
    public ExcepcionVocal() {
        super("Error: el carácter leído es una vocal.");
    }
}

