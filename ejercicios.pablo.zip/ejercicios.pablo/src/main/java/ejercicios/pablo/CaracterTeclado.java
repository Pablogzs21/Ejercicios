package ejercicios.pablo;

public class CaracterTeclado {
    private LeerPorTeclado lpt;

    public CaracterTeclado() {
        lpt = new LeerPorTeclado();
    }

    public void procesarCaracter() throws ExcepcionVocal, ExcepcionNumero, ExcepcionBlanco, ExcepcionSalida {
        char caracter = lpt.getChar();
        if (caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u' ||
                caracter == 'A' || caracter == 'E' || caracter == 'I' || caracter == 'O' || caracter == 'U') {
            throw new ExcepcionVocal();
        } else if (caracter >= '0' && caracter <= '9') {
            throw new ExcepcionNumero();
        } else if (caracter == ' ') {
            throw new ExcepcionBlanco();
        } else if (caracter == 'x' || caracter == 'X') {
            throw new ExcepcionSalida();
        }
    }
}

