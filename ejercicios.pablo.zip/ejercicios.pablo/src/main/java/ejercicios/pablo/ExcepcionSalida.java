package ejercicios.pablo;

public class ExcepcionSalida extends Exception {
    public ExcepcionSalida() {
        super("Programa finalizado por petición del usuario.");
    }
}

