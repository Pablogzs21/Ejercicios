package ejercicios.pablo;

public class ExcepcionBlanco extends Exception {
    public ExcepcionBlanco() {
        super("Error: el carácter leído es un espacio en blanco.");
    }
}

