package programacion;

import java.util.Scanner;

public class Ejercicio2 {
    int[] arrayNumeros;
    Scanner scanner = new Scanner(System.in);

    private int generarNumeroAleatorio(int min, int max) {
        return (int) (Math.random() * (max - min + 1) + min);
    }

    public void rellenarArray(int tamano, int min, int max) {
        arrayNumeros = new int[tamano];
        for (int i = 0; i < tamano; i++) {
            arrayNumeros[i] = generarNumeroAleatorio(min, max);
        }
    }

    public void mostrarArray() {
        int suma = 0;
        for (int i = 0; i < arrayNumeros.length; i++) {
            System.out.println("Posición " + i + ": " + arrayNumeros[i]);
            suma += arrayNumeros[i];
        }
        System.out.println("La suma de los valores es: " + suma);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el tamaño del array: ");
        int tamano = scanner.nextInt();
        Ejercicio2 arrayAleatorio = new Ejercicio2(); 
        arrayAleatorio.rellenarArray(tamano, 0, 9);
        arrayAleatorio.mostrarArray();
    }
}

