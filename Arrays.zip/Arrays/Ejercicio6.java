package programacion;
import java.util.Random;
public class Ejercicio6 {
    public static void main(String[] args) {
        int[][] matriz = new int[4][4];
        Random r = new Random();

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                matriz[i][j] = r.nextInt(10);
            }
        }

        System.out.println("Matriz original:");
        imprimirMatriz(matriz);

        System.out.println("Lectura de la matriz por filas:");
        leerMatrizPorFilas(matriz);

        System.out.println("Lectura de la matriz por columnas:");
        leerMatrizPorColumnas(matriz);

        System.out.println("Lectura de la matriz por filas en reversa:");
        leerMatrizPorFilasReversa(matriz);

        System.out.println("Lectura de la matriz por columnas en reversa:");
        leerMatrizPorColumnasReversa(matriz);

        System.out.println("Diagonal de la matriz:");
        leerDiagonalMatriz(matriz);
    }

    public static void imprimirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void leerMatrizPorFilas(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            System.out.print("Fila " + (i + 1) + ": ");
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void leerMatrizPorColumnas(int[][] matriz) {
        for (int i = 0; i < matriz[0].length; i++) {
            System.out.print("Columna " + (i + 1) + ": ");
            for (int j = 0; j < matriz.length; j++) {
                System.out.print(matriz[j][i] + " ");
            }
            System.out.println();
        }
    }

    public static void leerMatrizPorFilasReversa(int[][] matriz) {
        for (int i = matriz.length - 1; i >= 0; i--) {
            System.out.print("Fila " + (i + 1) + ": ");
            for (int j = matriz[0].length - 1; j >= 0; j--) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void leerMatrizPorColumnasReversa(int[][] matriz) {
        for (int i = matriz[0].length - 1; i >= 0; i--) {
        System.out.print("Columna " + (i + 1) + ": ");
        for (int j = matriz.length - 1; j >= 0; j--) {
            System.out.print(matriz[j][i] + " ");
        }
        System.out.println();
    }
}

    public static void leerDiagonalMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                if (i == j) {
                System.out.print(matriz[i][j] + " ");
            }
        }
    }
    System.out.println();
}
}

