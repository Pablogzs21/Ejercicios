package programacion;

public class Ejercicio7 {
    private String nombre;
    private String dni;
    private int edad;
    
    public Ejercicio7(String nombre, String dni, int edad) {
        this.nombre = nombre;
        this.dni = dni;
        this.edad = edad;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDni() {
        return dni;
    }
    
    public void setDni(String dni) {
        this.dni = dni;
    }
    
    public int getEdad() {
        return edad;
    }
    
    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public boolean equals(Object obj) {
        if (obj instanceof Ejercicio7) {
            Ejercicio7 otraPersona = (Ejercicio7) obj;
            return this.dni.equals(otraPersona.dni);
        }
        return false;
    }

    public static void main(String[] args) {
        Ejercicio7[] personas = new Ejercicio7[10];
        
        personas[0] = new Ejercicio7("Juan", "12345678A", 30);
        personas[1] = new Ejercicio7("María", "23456789B", 25);
        personas[2] = new Ejercicio7("Pedro", "34567890C", 45);
        personas[3] = new Ejercicio7("Ana", "45678901D", 35);
        personas[4] = new Ejercicio7("Sara", "56789012E", 20);
        personas[5] = new Ejercicio7("Carlos", "67890123F", 50);
        personas[6] = new Ejercicio7("Luis", "78901234G", 40);
        personas[7] = new Ejercicio7("Eva", "89012345H", 27);
        personas[8] = new Ejercicio7("Diego", "90123456I", 31);
        personas[9] = new Ejercicio7("Isabel", "01234567J", 28);
       
        for (Ejercicio7 e : personas) {
            System.out.println("Nombre: " + e.getNombre() + ", DNI: " + e.getDni() + ", Edad: " + e.getEdad());
        }
        
        Ejercicio7 personaMayorEdad = buscarPersonaMayorEdad(personas);
        System.out.println("La primera persona con mayor edad es: " + personaMayorEdad.getNombre() 
            + " (Edad: " + personaMayorEdad.getEdad() + ")");
    }
    
    public static Ejercicio7 buscarPersonaMayorEdad(Ejercicio7[] personas) {
        Ejercicio7 personaMayorEdad = personas[0];
        for (int i = 1; i < personas.length; i++) {
            if (personas[i].getEdad() > personaMayorEdad.getEdad()) {
                personaMayorEdad = personas[i];
            }
        }
        return personaMayorEdad;
    }
    
}
