package programacion;

public class Ejercicio4 {
    public static boolean compararArraysString(String[] array1, String[] array2) {

    if (array1.length != array2.length) {
        return false;
    }

    for (int i = 0; i < array1.length; i++) {
        if (!array1[i].equals(array2[i])) {
            return false;
        }
    }

    return true;
}

public static void main(String[] args) {
    String[] array1 = {"Hola", "Mundo", "!"};
    String[] array2 = {"Hola", "Mundo", "!"};

    boolean sonIguales = compararArraysString(array1, array2);

    if (sonIguales) {
        System.out.println("Los arrays son iguales.");
    } else {
        System.out.println("Los arrays son diferentes.");
    }
}


    
}
