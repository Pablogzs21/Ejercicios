package programacion;

import java.util.Scanner;

public class Ejercicio1 {
    int[] arrayNumeros = new int[10];
    Scanner scanner = new Scanner(System.in);

    public void rellenarArray() {
        for(int i=0; i<arrayNumeros.length; i++) {
            System.out.print("Introduce el valor para la posición " + i + ": ");
            arrayNumeros[i] = scanner.nextInt();
        }
    }

    public void mostrarArray() {
        for(int i=0; i<arrayNumeros.length; i++) {
            System.out.println("Índice: " + i + ", valor: " + arrayNumeros[i]);
        }
    }

    public static void main(String[] args) {
        Ejercicio1 ejercicio1 = new Ejercicio1();
        ejercicio1.rellenarArray();
        ejercicio1.mostrarArray();
    }
}


